/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog1atask1;
import java.util.regex.Pattern;
import java.util.Scanner; 
/**
 *
 * @author User
 */
public class Prog1ATask1 {

    public static void main(String[] args) {
               Scanner sc = new Scanner(System.in);

        System.out.print("Enter first name: ");
        String firstName = sc.nextLine();

        System.out.print("Enter last name: ");
        String lastName = sc.nextLine();

        System.out.print("Enter username: ");
        String username = sc.nextLine();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        System.out.print("Enter cell phone number (+27xxxxxxxxx): ");
        String cell = sc.nextLine();

        Login login = new Login(username, password, cell, firstName, lastName);
         System.out.println(login.registerUser());

        System.out.print("\nLogin username: ");
        String loginUsername = sc.nextLine();

        System.out.print("Login password: ");
        String loginPassword = sc.nextLine();

        boolean success = login.loginUser(loginUsername, loginPassword);
        System.out.println(login.returnLoginStatus(success));

        sc.close();
    }
    }

